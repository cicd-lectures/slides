#! /bin/sh

echo "Lancement du menu-server, accrochez vous bien!"
java -jar dist/menu-server.jar
